import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.net.*;
import java.applet.AudioClip;
import java.util.Random;
import java.util.ArrayList;
import acm.graphics.*;
import acm.program.GraphicsProgram;

/*
 * READ THIS FIRST
 * ---------------
 * This file contains several "pieces"
 * of the program that are already set up for you.
 * 
 * You should treat these as strong suggestions/hints
 * for how to go about getting the game working, but you
 * are free to alter anything you want to, as long as the final
 * result behaves the same way the demo does.
 * 
 * Before you start coding, read through all the other comments
 * I have placed throughout the already-existing code.
 * 
 */

@SuppressWarnings("serial")
public class MainProgram extends GraphicsProgram
{
	/*
	 * CONSTANTS
	 * All of these variables are constants ("final" in Java terms)
	 * that control various aspects of the game.
	 * You might need to "tweak" them to get the exact behavior
	 * you want, but they should also work well enough as is.
	 */
	// board dimensions
	final private int BOARD_WIDTH = 600; 
	final private int BOARD_HEIGHT = 600; 
	// vertical size of the paddle
	final private int PADDLE_HEIGHT = 10; 
	// the standard timer delay amount,
	// used when the difficulty is set to 1.
	final private int STANDARD_TIMER_DELAY = 40;
	// the number of misses allowed before the game ends
	final private int MISSSES_ALLOWED = 20;
	// how far the paddle moves, if it is moving, during each timer tick
	final private int PADDLE_MOTION_PER_TICK = 12;

	/*
	 * SWING COMPONENTS / CONTROLS
	 * These fields correspond to the JPanel 
	 * that displays the game controls
	 * and the individual Swing components
	 * that constitute those controls.
	 */	
	private JPanel controlPanel;
	private JSlider slider;
	private JButton button;
	
	/*
	 * THE TIMER
	 * The game as a whole is "run" by a single timer object.
	 * Here it is.
	 */
	private Timer timer;

	/*
	 * ACTIVE GAME VARIABLES
	 * This set of fields includes variables
	 * for tracking things that change or move while the game
	 * is being played.
	 */	
	// The paddle and its current width
	private GRect paddle;
	private int PADDLE_WIDTH = 100;
	// The set of crates
	ArrayList<Crate> crates;
	// Whether or not the game is running
	private boolean running = false;
	// The current score
	private int score = 0;
	
	/*
	 * THE setupControls() METHOD
	 * This method is **partially** complete.
	 * It sets up the control panel and places it in the right
	 * place on the screen.
	 */
	private void setupControls()
	{
		slider = new JSlider(1, 5, 1);

		controlPanel.add(new JLabel("Difficulty"));
		controlPanel.add(slider);
				
		button = new JButton("Start");
		controlPanel.add(button);
		
		// Creates some vertical space between the button and the high
		// score panel
		controlPanel.add(Box.createVerticalStrut(20));
		
		// Setup for the high score panel
		// NOTE: This needs to have a grid layout applied to it
		//       so the labels and numbers line up correctly.
		JPanel highscorePanel = new JPanel();
		highscorePanel.setBorder(new LineBorder(Color.WHITE, 20));
		highscorePanel.add(new JLabel("Level"));
		highscorePanel.add(new JLabel("High Score"));
		// Add 10 labels, which make up the contents of the
		// high score display
		for (int i = 0; i < 10; i++)
		{
			highscorePanel.add(new JLabel("..."));
		}
		controlPanel.add(highscorePanel);
		
		// This is needed to make sure the components of the control
		// panel don't "spread out" unnaturally
		controlPanel.add(Box.createGlue());
	}
	
	/*
	 * THE init() METHOD
	 * This is the GraphicsProgram's equivalent of
	 * a "main function." Program execution will begin here.
	 */
	public void init()
	{
		setSize(BOARD_WIDTH+200, BOARD_HEIGHT);
		setBackground(Color.BLACK);

		// Instantiate the list of crates
		crates = new ArrayList<Crate>();

		// Instantiate and set up the control panel
		controlPanel = new JPanel();
		controlPanel.setSize(200, BOARD_HEIGHT);
		controlPanel.setLocation(BOARD_WIDTH, 0);
		// line up components in a vertical stack
		controlPanel.setLayout(new BoxLayout(controlPanel, BoxLayout.Y_AXIS));
		// calling setupControls() to add all the individual compontents
		setupControls();
		// This loop makes all the components aligned nicely
		for (Component c : controlPanel.getComponents())
		{
			((JComponent)c).setAlignmentX(CENTER_ALIGNMENT);
		}
		// Add the control panel to the screen
		getGCanvas().add(controlPanel);
		
		// Instantiate the timer
		timer = new Timer(STANDARD_TIMER_DELAY, new TickTicker());
		
	}

	
	/*
	 * THE TickTicker CLASS
	 * This is an inner class that implements ActionListener.
	 * When the user hits the "Start" button, the timer object
	 * should be started. That will cause the actionPerformed 
	 * method in this class to get called at every timer tick.
	 * The body of the actionPerformed method needs to 
	 * execute all motion and any other changes needed to
	 * handle updating the state of the game.
	 */
	private class TickTicker implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			// Update the state of the game. This includes:
			// * move the crates
			// * move the paddle (if it is moving)
			// * check for crates that have been caught
			// * check for crates that have been missed
			// * play sounds as appropriate
			// * check whether the game is over, and react accordingly
		}
	}

}

