import java.awt.Color;
import java.util.Random;
import acm.graphics.*;

/*
 * The Crate class is used for individual falling crates
 * to be placed in the game area and then animated.
 * 
 * Be creative in deciding how to arrange the appearance of a crate
 * but MAKE SURE IT IS RECTANGULAR overall - otherwise, detecting
 * whether it has hit the paddle will not work.
 */

public class Crate extends GCompound
{
	// descentRate: Controls how quickly the crate falls
	private double descentRate = 0;
	
	public Crate()
	{
		// Initialize internal data appropriately, creating
		// a crate with a RANDOM SIZE, a RANDOM COLOR 
		// and a RANDOM DESCENT RATE. Each of these randomly
		// set properties should be within a reasonable range.
	}
	public void moveDown()
	{
		// Move this crate object downward once, using the descentRate
		// to control how far it moves.
	}
}
